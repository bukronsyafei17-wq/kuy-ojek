self.addEventListener('fetch', function(event) {
  // Service worker sederhana untuk memenuhi syarat installable PWA
});